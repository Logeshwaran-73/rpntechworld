import React from 'react';
import 'react-phone-input-2/lib/style.css';
import './WhyChooseUs.css';
import PhoneInput from 'react-phone-input-2';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const fadeInUp = {
  hidden: { opacity: 0, y: 50 },
  visible: { opacity: 1, y: 0 },
};

const WhyChooseUs = () => {
  const { ref: leftRef, inView: leftInView } = useInView({ triggerOnce: true });
  const { ref: rightRef, inView: rightInView } = useInView({ triggerOnce: true });

  return (
    <div className="why-choose-us">
      <motion.div
        className="left-side"
        ref={leftRef}
        variants={fadeInUp}
        initial="hidden"
        animate={leftInView ? "visible" : "hidden"}
        transition={{ duration: 0.8 }}
      >
        <h1>Why Choose Us</h1>
        <h2>The Top Web Design & Development Team</h2>
        <div className="features">
          <div className="feature1">
            <p>Dynamic Websites with attractive web designs</p>
          </div>
          <div className="feature2">
            <p>Projects will deliver on time with proper analysis</p>
          </div>
          <div className="feature3">
            <p>24x7 Customer call support</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        className="right-side"
        ref={rightRef}
        variants={fadeInUp}
        initial="hidden"
        animate={rightInView ? "visible" : "hidden"}
        transition={{ duration: 0.8 }}
      >
        <h2>Get In Touch</h2>
        <form className="contact-form">
          <input type="text" placeholder="Name" />
          <PhoneInput
            country={'us'}
            value=""
            onChange={() => {}}
            inputStyle={{
              width: '100%',
              backgroundColor: 'rgba(255, 255, 255, 0.2)',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              padding: '10px',
              marginBottom: '10px',
              textAlign: 'justify',
            }}
            buttonStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          />
          <input type="email" placeholder="Email" />
          <select>
            <option>Select Service</option>
            <option>Web Development</option>
            <option>UX/UI Design</option>
            <option>Branding</option>
            <option>Social Media Marketing</option>
          </select>
          <div className="msg">
            <textarea placeholder="Message"></textarea>
          </div>
          <div className="terms">
            <input type="checkbox" id="terms" />
            <label htmlFor="terms">I agree to the terms and conditions</label>
          </div>
          <button type="submit">Submit</button>
        </form>
      </motion.div>
    </div>
  );
};

export default WhyChooseUs;
