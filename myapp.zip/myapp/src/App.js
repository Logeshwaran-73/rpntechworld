import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Proj from './Components/Proj';


// import WhatWeDo from './Components/WhatWeDo';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import './App.css'
// import Proj from './Components/Proj';
// import CarouselPage from './Components/CarouselPage';
// import proj1 from './Components/proj1';
// import proj2 from './Components/proj2';

function App() {
  return (
    <div className="App">
      <Proj/>
      
    {/* <Proj/> */}
    {/* <proj1/> */}
    {/* <proj2/> */}
    {/* <CarouselPage/> */}
    {/* <WhatWeDo/> */}
    </div>
  );
}


export default App;
